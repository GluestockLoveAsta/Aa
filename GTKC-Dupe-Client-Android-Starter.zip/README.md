# GTKC Dupe Client — Android starter

A blue/black Android companion app with a basic floating overlay and a list of Bedrock monitoring/private-world test tools.

## Build
Push this repository to GitHub. Open **Actions → Build GTKC Android APK → Run workflow**. Download the `GTKC-debug-apk` artifact when the workflow succeeds.

## Important limitations
- This is a companion UI, not a Minecraft client injection/modification.
- The overlay requires the Android “Display over other apps” permission.
- Android/Bedrock add-ons cannot independently read a remote server's internal patch state.
- No item duplication exploit or automated public-server exploit is included. The listed tools are checklists/logging placeholders.
- Android SDK/Gradle build availability depends on GitHub Actions and may require dependency/version updates.
