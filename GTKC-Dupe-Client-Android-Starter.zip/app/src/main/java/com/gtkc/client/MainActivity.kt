package com.gtkc.client

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val blue = 0xFF2583FF.toInt()
    private val dark = 0xFF080D18.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 24)
            setBackgroundColor(dark)
        }
        page.addView(TextView(this).apply {
            text = "GTKC"
            textSize = 32f
            setTextColor(blue)
        })
        page.addView(TextView(this).apply {
            text = "DUPE CLIENT  •  BEDROCK TOOLKIT"
            textSize = 13f
            setTextColor(0xFFB7C7DF.toInt())
            setPadding(0, 4, 0, 24)
        })
        page.addView(TextView(this).apply {
            text = "Monitoring and private-world testing tools\nThese tools do not perform item duplication or detect server-side patches."
            textSize = 14f
            setTextColor(0xFFE7EEF9.toInt())
            setPadding(0, 0, 0, 20)
        })
        val overlay = Button(this).apply {
            text = "Enable floating GTKC panel"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                }
            }
        }
        page.addView(overlay)
        val modules = listOf(
            "Anvil interaction log", "Anvil test checklist", "Inventory counter",
            "Item transfer checklist", "Container interaction log", "Chest session log",
            "Shulker session log", "Item name tracker", "Item quantity tracker",
            "World version notes", "Connection latency notes", "Session timer",
            "Manual patch notes", "Private-world test log", "Save test results",
            "Export test report", "Config save", "Config load",
            "Quick reference", "Module status", "About GTKC"
        )
        page.addView(TextView(this).apply {
            text = "\nTOOLS"
            textSize = 18f
            setTextColor(blue)
        })
        modules.forEach { name ->
            page.addView(TextView(this).apply {
                text = "  •  $name"
                textSize = 15f
                setTextColor(0xFFE7EEF9.toInt())
                setPadding(8, 12, 8, 12)
                setBackgroundColor(0xFF111B2C.toInt())
            })
        }
        setContentView(ScrollView(this).apply { addView(page) })
    }
}
