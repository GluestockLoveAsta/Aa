plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.gtkc.client"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.gtkc.client"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
